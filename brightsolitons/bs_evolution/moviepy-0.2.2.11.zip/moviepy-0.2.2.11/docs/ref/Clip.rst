************
Clip
************

:class:`Clip`
==========================

.. autoclass:: Clip.Clip
   :members:
   :show-inheritance:
