moviepy.video.fx.all.headblur
=============================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: headblur