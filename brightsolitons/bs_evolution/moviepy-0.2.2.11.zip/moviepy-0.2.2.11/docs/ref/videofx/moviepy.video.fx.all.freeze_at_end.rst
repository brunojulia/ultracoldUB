moviepy.video.fx.all.freeze_at_end
==================================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: freeze_at_end