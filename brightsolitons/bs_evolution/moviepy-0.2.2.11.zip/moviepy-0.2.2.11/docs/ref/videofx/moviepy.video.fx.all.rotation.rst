moviepy.video.fx.all.rotation
=============================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: rotation