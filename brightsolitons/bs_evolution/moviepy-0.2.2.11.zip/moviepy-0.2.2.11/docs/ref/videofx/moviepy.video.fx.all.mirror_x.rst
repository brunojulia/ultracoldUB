moviepy.video.fx.all.mirror_x
=============================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: mirror_x