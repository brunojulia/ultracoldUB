moviepy.video.fx.all.resize
===========================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: resize