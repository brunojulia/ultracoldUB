moviepy.video.fx.all.freeze_at_start
====================================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: freeze_at_start