moviepy.video.fx.crop
=====================

.. currentmodule:: moviepy.video.fx

.. autofunction:: crop