.. charDuplication:

Character duplication in a video
-----------------------------------


.. raw:: html

        <center>
        <object><param name="movie"
        value="http://www.youtube.com/v/sZMyzzGlsc0&hl=en_US&fs=1&rel=0">
        </param><param name="allowFullScreen" value="true"></param><param
        name="allowscriptaccess" value="always"></param><embed
        src="http://www.youtube.com/v/sZMyzzGlsc0&hl=en_US&fs=1&rel=0"
        type="application/x-shockwave-flash" allowscriptaccess="always"
        allowfullscreen="true" width="550" height="450"></embed></object>
        </center>


So blabla
