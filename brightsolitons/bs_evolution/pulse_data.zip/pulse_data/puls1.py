# -*- coding: utf-8 -*-
"""
Created on Sat Nov 05 11:43:23 2016

@author: laura18
"""

### Program dedicated to create the simulation of a pulse on a string

import numpy as np

def STRING(velocity,boundary,B,X,Dx,Dt,U0,UP0,Tmax,N):
    """Where:
    velocity....velocity of the pulse, i.e. of the soliton
    boundary....boundary conditions +1 if attached to a mass equal to 1
                                       0 if fixed
                                      -1 if free
    B...........damping coefficient
    X(N)........spatial grid points
    Dx..........spacing of the spatial grid
    Dt..........time step
    U0(N).......wave function at T=0, U(I)=U(X0-DX+I*DX)
    UP0(N)......time derivative of the wave function at T=0
    Tmax........the solution is discontinued when t>Tmax
    N...........number of space grid points"""
    
    global UMIN, UMAX
       
    NP=10000              #N must be smaller than NP!
    UOLD=np.empty([NP])
    UNEW=np.empty([NP])
    U=np.empty([NP])
    
    alpha=(velocity*Dt/Dx)**2  #should be unity!!!!
    beta=B*Dt
    
    T=0.0
    Nt=0
    
    for i in range(0,N):
        UOLD[i]=U0[i]
    
    UMIN=1.0e35
    UMAX=-1.0e35
    
    string=open('string-%08d.dat' %round(Nt),'w')
    
    string.write('#Initial state = 0 \n')
    for i in range(0,N):
        UMIN=min(UMIN,UOLD[i])
        UMIN=max(UMAX,UOLD[i])        
        string.write('%.15f \t %.15f \n' %(X[i],UOLD[i]))
    
    string.close()
    
    #First time step
    T+=Dt
    Nt+=1
    for i in range(1,N-1):
        U[i]=((2.0 - 2.0*alpha)*U0[i]+alpha*(U0[i+1]+U0[i-1])+(1.0-beta)*2.0*Dt*UP0[i])/2.00
    
    #Boundary conditions, we want it fixed:
    U[0]=0.0
    U[N-1]=0.0
    
    for i in range(0,N):
        UMIN=min(UMIN,U[i])
        UMAX=max(UMAX,U[i])
        
    #next time step
    while (T<Tmax):
        T+=Dt
        Nt+=1
        for i in range(1,N-1):
            UNEW[i]=((2.0 - 2.0*alpha)*U[i]+alpha*(U[i+1]+U[i-1])-(1.0-beta)*UOLD[i])/(1.0+beta)
    
    #Boundary conditions once again, fixed
        UNEW[0]=0.0
        UNEW[N-1]=0.0 
        
        if not(Nt%4):
            string=open('string-%08d.dat' %(round(Nt)),'w')       
            string.write('state T = %f %f \n' %(T,Nt))
        else:
            continue
        
        for i in range(0,N):
            UMIN=min(UMIN,UNEW[i])
            UMAX=max(UMAX,UNEW[i])
            if not(Nt%4):
                string.write('%.15f \t %.15f \n' %(X[i],UNEW[i]))
            else:
                continue
    
        for i in range(0,N):
            UOLD[i]=U[i]
            U[i]=UNEW[i]

        if not(Nt%4):
            string.close()
        else:
            continue        
    
    return None
    
#----------------------------------------------------------------------
    
def Wave0(X,c,U0,UP0,x0):
    """Where:
    X(N).......spatial grid points
    c..........velocity of the wave, c>0 wave travelling to the right
    U0.........Initial wave function
    UP0........Derivative initial wave function"""
    T=0.0
    Z=X-c*T
    # we will deifne the wave function as U(X,T) = exp(-100.0*(Z-x0)**2)
    U0=np.exp(-500*(Z-x0)**2)
    UP0=-c*(-500*2.0*(Z-x0)*U0)
    return U0,UP0
    
#-----------------------------------------------------------------------
    
    """MAIN PROGRAM"""
    
global UMIN,UMAX
    
Strl = 1.92
c = 10000.0
x0 = -0.50  #initial position
BCM=0.0  #boundary conditions. Both fixed
B=0.0    #damping coefficient
        
N=385 #number of points in the X grid
NP=1000

Dx=Strl/float(N-1)
#Dt=Dx/c   #Courant
Dt=0.00000010000
    
X=np.empty([NP])
U0=np.empty([N])
UP0=np.empty([N])
    
Tmax=Dt*5000  #max time
    
#Initial conditions
XX=-(Strl/2.0)-1.0*Dx
T=0.0

arxiu=open('gaussiana.dat','w')
for i in range(0,N):
    XX+=Dx
    U0[i],UP0[i]=Wave0(XX,c,U0[i],UP0[i],x0) #travelling right
    X[i]=XX
    arxiu.write('%.15f \t %.15f \n' %(X[i],U0[i]))
arxiu.close()
STRING(c,BCM,B,X,Dx,Dt,U0,UP0,Tmax,N)
        